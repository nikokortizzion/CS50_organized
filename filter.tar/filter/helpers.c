#include "helpers.h"
#include <math.h>
#include <stdlib.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            // Create variables for that iteration of loop
            float color = 0;
            int count = 0;
            int colors[3] = {image[i][j].rgbtBlue, image[i][j].rgbtGreen, image[i][j].rgbtRed};

            // Calculate the average of the red, green, and blue values
            for (int k = 0; k < 3; k++)
            {
                color += colors[k];
                count++;
            }
            color = color / count + 0.5;

            // Write value of average color in pixel
            image[i][j].rgbtBlue = color;
            image[i][j].rgbtGreen = color;
            image[i][j].rgbtRed = color;
        }
    }
}

// Convert image to sepia
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            // Calculate formula of sepia colors
            float sepiaRed = .393 * image[i][j].rgbtRed + .769 * image[i][j].rgbtGreen + .189 * image[i][j].rgbtBlue;
            sepiaRed = (int)roundf(sepiaRed);
            float sepiaGreen = .349 * image[i][j].rgbtRed + .686 * image[i][j].rgbtGreen + .168 * image[i][j].rgbtBlue;
            sepiaGreen = (int)roundf(sepiaGreen);
            float sepiaBlue = .272 * image[i][j].rgbtRed + .534 * image[i][j].rgbtGreen + .131 * image[i][j].rgbtBlue;
            sepiaBlue = (int)roundf(sepiaBlue);

            // Write new values of colors in pixel
            if (sepiaRed >= 0 && sepiaRed <= 255)
            {
                image[i][j].rgbtRed = sepiaRed;
            }
            else
            {
                image[i][j].rgbtRed = 255;
            }

            if (sepiaGreen >= 0 && sepiaGreen <= 255)
            {
                image[i][j].rgbtGreen = sepiaGreen;
            }
            else
            {
                image[i][j].rgbtGreen = 255;
            }

            if (sepiaBlue >= 0 && sepiaBlue <= 255)
            {
                image[i][j].rgbtBlue = sepiaBlue;
            }
            else
            {
                image[i][j].rgbtBlue = 255;
            }
        }
    }
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width / 2; j++)
        {
            // Switch values of opposite pixels in the row
            RGBTRIPLE temp = image[i][j];
            image[i][j] = image[i][width - 1 - j];
            image[i][width - 1 - j] = temp;
        }
    }
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    // Create pointer temp and allocate memory wich equal to size of image
    RGBTRIPLE(*temp)[width] = calloc(height, width * sizeof(RGBTRIPLE));
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            float averageRed = 0, averageGreen = 0, averageBlue = 0;
            int counter = 0;
            // Calculating loop for rgbtRed
            for (int c = -1; c < 2; c++)
            {
                for (int k = -1; k < 2; k++)
                {
                    if ((i + c >= 0 && j + k >= 0) && (i + c <= height - 1 && j + k <= width - 1))
                    {
                        averageRed += image[i + c][j + k].rgbtRed;
                        counter++;
                    }
                }
            }
            averageRed = averageRed / counter + 0.5;
            counter = 0;

            // Calculating loop for rgbtGreen
            for (int c = -1; c < 2; c++)
            {
                for (int k = -1; k < 2; k++)
                {
                    if ((i + c >= 0 && j + k >= 0) && (i + c <= height - 1 && j + k <= width - 1))
                    {
                        averageGreen += image[i + c][j + k].rgbtGreen;
                        counter++;
                    }
                }
            }
            averageGreen = averageGreen / counter + 0.5;
            counter = 0;

            // Calculating loop for rgbtBlue
            for (int c = -1; c < 2; c++)
            {
                for (int k = -1; k < 2; k++)
                {
                    if ((i + c >= 0 && j + k >= 0) && (i + c <= height - 1 && j + k <= width - 1))
                    {
                        averageBlue += image[i + c][j + k].rgbtBlue;
                        counter++;
                    }
                }
            }
            averageBlue = averageBlue / counter + 0.5;
            counter = 0;

            // Write calculated values of colors in the given pixel
            temp[i][j].rgbtRed = (int)averageRed;
            temp[i][j].rgbtGreen = (int)averageGreen;
            temp[i][j].rgbtBlue = (int)averageBlue;
        }
    }

    // Write values of colors from temp to image
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j] = temp[i][j];
        }
    }
    free(temp);
}
